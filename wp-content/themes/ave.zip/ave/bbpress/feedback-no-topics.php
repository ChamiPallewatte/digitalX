<?php

/**
 * No Topics Feedback Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<div class="bbp-template-notice">
	<p><?php esc_html_e( 'Oh bother! No topics were found here!', 'ave' ); ?></p>
</div>
