
<?php $this->entry_thumbnail( 'liquid-carousel-blog' ); ?>

<header class="liquid-lp-header">
	<?php $this->entry_title( 'h3' ); ?>
</header>

<?php $this->entry_content(); ?>

<footer class="liquid-lp-footer">
	<?php $this->entry_tags( 'bordered circle' ); ?>
</footer>