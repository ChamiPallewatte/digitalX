<div class="lqd-preloader-wrap lqd-preloader-signal" data-preloader-options='{ "animationType": "fade" }'>
	<div class="lqd-preloader-inner">

		<div class="lqd-preloader-signal-el">
			<div class="lqd-preloader-signal-circle"></div>
			<div class="lqd-preloader-signal-circle"></div>
			<div class="lqd-preloader-signal-circle"></div>
		</div>

	</div><!-- /.lqd-preloader-inner -->
</div><!-- /.lqd-preloader-wrap -->