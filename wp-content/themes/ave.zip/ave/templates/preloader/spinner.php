<div class="lqd-preloader-wrap lqd-preloader-spinner" data-preloader-options='{ "animationType": "fade" }'>
	<div class="lqd-preloader-inner">

		<div class="lqd-preloader-el">

			<svg class="lqd-spinner-circular" height="64" width="64">
				<circle cx="32" cy="32" r="28" fill="none" stroke-width="5" stroke-miterlimit="10" />
			</svg>

		</div><!-- /.lqd-preloader-el -->

	</div><!-- /.lqd-preloader-inner -->
</div><!-- /.lqd-preloader-wrap -->