<div class="lqd-preloader-wrap lqd-preloader-curtain" data-preloader-options='{ "animationType": "slide", "animationTargets": ".lqd-preloader-curtain-el", "stagger": 215 }'>
	<div class="lqd-preloader-inner">

		<div class="lqd-preloader-curtain-el lqd-preloader-curtain-front"></div>
		<div class="lqd-preloader-curtain-el lqd-preloader-curtain-back"></div>

	</div><!-- /.lqd-preloader-inner -->
</div><!-- /.lqd-preloader-wrap -->