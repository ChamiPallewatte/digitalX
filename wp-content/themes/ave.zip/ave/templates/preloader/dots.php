<div class="lqd-preloader-wrap lqd-preloader-dots" data-preloader-options='{ "animationType": "fade" }'>
	<div class="lqd-preloader-inner">

		<div class="lqd-preloader-dots-el">
			<div class="lqd-preloader-dots-dot"></div>
			<div class="lqd-preloader-dots-dot"></div>
			<div class="lqd-preloader-dots-dot"></div>
		</div><!-- /.lqd-preloader-dots-el -->

	</div><!-- /.lqd-preloader-inner -->
</div><!-- /.lqd-preloader-wrap -->