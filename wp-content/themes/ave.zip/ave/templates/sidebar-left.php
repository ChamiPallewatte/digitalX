<div class="col-md-3 sidebar-container">
	<aside class="main-sidebar">
		<?php dynamic_sidebar( liquid()->layout->sidebars['sidebar'] ) ?>
	</aside>
</div>